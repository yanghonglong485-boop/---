from typing import List, Dict, Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision
from torchvision.ops import roi_pool, box_iou, clip_boxes_to_image, nms


def encode_boxes(reference_boxes, proposals):
    # targets for bbox regression: (tx, ty, tw, th)
    ex_widths = proposals[:, 2] - proposals[:, 0]
    ex_heights = proposals[:, 3] - proposals[:, 1]
    ex_ctr_x = proposals[:, 0] + 0.5 * ex_widths
    ex_ctr_y = proposals[:, 1] + 0.5 * ex_heights

    gt_widths = reference_boxes[:, 2] - reference_boxes[:, 0]
    gt_heights = reference_boxes[:, 3] - reference_boxes[:, 1]
    gt_ctr_x = reference_boxes[:, 0] + 0.5 * gt_widths
    gt_ctr_y = reference_boxes[:, 1] + 0.5 * gt_heights

    ex_widths = torch.clamp(ex_widths, min=1e-6)
    ex_heights = torch.clamp(ex_heights, min=1e-6)

    tx = (gt_ctr_x - ex_ctr_x) / ex_widths
    ty = (gt_ctr_y - ex_ctr_y) / ex_heights
    tw = torch.log(torch.clamp(gt_widths / ex_widths, min=1e-6))
    th = torch.log(torch.clamp(gt_heights / ex_heights, min=1e-6))
    return torch.stack((tx, ty, tw, th), dim=1)


def decode_boxes(deltas, proposals):
    widths = proposals[:, 2] - proposals[:, 0]
    heights = proposals[:, 3] - proposals[:, 1]
    ctr_x = proposals[:, 0] + 0.5 * widths
    ctr_y = proposals[:, 1] + 0.5 * heights

    dx = deltas[:, 0]
    dy = deltas[:, 1]
    dw = deltas[:, 2].clamp(max=4.135)
    dh = deltas[:, 3].clamp(max=4.135)

    pred_ctr_x = dx * widths + ctr_x
    pred_ctr_y = dy * heights + ctr_y
    pred_w = torch.exp(dw) * widths
    pred_h = torch.exp(dh) * heights

    x1 = pred_ctr_x - 0.5 * pred_w
    y1 = pred_ctr_y - 0.5 * pred_h
    x2 = pred_ctr_x + 0.5 * pred_w
    y2 = pred_ctr_y + 0.5 * pred_h
    return torch.stack((x1, y1, x2, y2), dim=1)


def batch_images(images: List[torch.Tensor], size_divisible=32):
    max_h = max(img.shape[1] for img in images)
    max_w = max(img.shape[2] for img in images)
    max_h = int((max_h + size_divisible - 1) // size_divisible * size_divisible)
    max_w = int((max_w + size_divisible - 1) // size_divisible * size_divisible)
    batch = images[0].new_zeros((len(images), 3, max_h, max_w))
    image_sizes = []
    for i, img in enumerate(images):
        c, h, w = img.shape
        batch[i, :c, :h, :w] = img
        image_sizes.append((h, w))
    return batch, image_sizes


class FastRCNN(nn.Module):
    def __init__(self, num_classes: int, backbone_weights: str = None):
        super().__init__()

        # 不再触发 torchvision 自动联网下载
        backbone = torchvision.models.resnet50(weights=None)

        # 如果给了本地权重，就从本地加载
        if backbone_weights is not None and len(backbone_weights) > 0:
            state_dict = torch.load(backbone_weights, map_location="cpu")
            backbone.load_state_dict(state_dict, strict=False)
        # Use conv1..layer3 as shared conv feature extractor (stride 16).
        self.backbone = nn.Sequential(
            backbone.conv1,
            backbone.bn1,
            backbone.relu,
            backbone.maxpool,
            backbone.layer1,
            backbone.layer2,
            backbone.layer3,
        )
        self.out_channels = 1024
        self.spatial_scale = 1.0 / 16.0
        self.fc1 = nn.Linear(self.out_channels * 7 * 7, 1024)
        self.fc2 = nn.Linear(1024, 1024)
        self.cls_score = nn.Linear(1024, num_classes)
        self.bbox_pred = nn.Linear(1024, num_classes * 4)
        self.num_classes = num_classes

    def _sample_rois(self, proposals, targets, batch_size_per_img=64, positive_fraction=0.25):
        all_rois, all_labels, all_reg_targets = [], [], []
        for props, tgt in zip(proposals, targets):
            gt_boxes = tgt["boxes"]
            gt_labels = tgt["labels"]

            if gt_boxes.numel() > 0:
                props = torch.cat([props, gt_boxes], dim=0)
                iou = box_iou(props, gt_boxes)
                max_iou, matched = iou.max(dim=1)

                labels = torch.zeros((props.shape[0],), dtype=torch.long, device=props.device)
                positive = max_iou >= 0.5
                negative = (max_iou < 0.5) & (max_iou >= 0.1)
                labels[positive] = gt_labels[matched[positive]]
            else:
                labels = torch.zeros((props.shape[0],), dtype=torch.long, device=props.device)
                positive = torch.zeros_like(labels, dtype=torch.bool)
                negative = torch.ones_like(labels, dtype=torch.bool)
                matched = torch.zeros((props.shape[0],), dtype=torch.long, device=props.device)

            num_pos = min(int(batch_size_per_img * positive_fraction), int(positive.sum().item()))
            num_neg = min(batch_size_per_img - num_pos, int(negative.sum().item()))

            pos_idx = torch.where(positive)[0]
            neg_idx = torch.where(negative)[0]

            if len(pos_idx) > 0 and num_pos > 0:
                pos_idx = pos_idx[torch.randperm(len(pos_idx), device=props.device)[:num_pos]]
            else:
                pos_idx = pos_idx[:0]

            if len(neg_idx) > 0 and num_neg > 0:
                neg_idx = neg_idx[torch.randperm(len(neg_idx), device=props.device)[:num_neg]]
            else:
                neg_idx = neg_idx[:0]

            keep = torch.cat([pos_idx, neg_idx], dim=0)
            sampled_props = props[keep]
            sampled_labels = labels[keep]

            reg_targets = torch.zeros((sampled_props.shape[0], 4), dtype=torch.float32, device=props.device)
            if gt_boxes.numel() > 0 and len(pos_idx) > 0:
                pos_mask = sampled_labels > 0
                pos_matched_gt = gt_boxes[matched[keep[pos_mask]]]
                reg_targets[pos_mask] = encode_boxes(pos_matched_gt, sampled_props[pos_mask])

            all_rois.append(sampled_props)
            all_labels.append(sampled_labels)
            all_reg_targets.append(reg_targets)
        return all_rois, all_labels, all_reg_targets

    def _forward_head(self, features, rois):
        pooled = roi_pool(features, rois, output_size=(7, 7), spatial_scale=self.spatial_scale)
        x = pooled.flatten(start_dim=1)
        x = F.relu(self.fc1(x))
        x = F.dropout(x, p=0.5, training=self.training)
        x = F.relu(self.fc2(x))
        x = F.dropout(x, p=0.5, training=self.training)
        cls_logits = self.cls_score(x)
        bbox_deltas = self.bbox_pred(x).view(-1, self.num_classes, 4)
        return cls_logits, bbox_deltas

    def forward(self, images: List[torch.Tensor], proposals: List[torch.Tensor], targets=None):
        device = images[0].device
        batch, image_sizes = batch_images(images)
        features = self.backbone(batch)

        if self.training:
            rois, labels_list, reg_targets_list = self._sample_rois(proposals, targets)
            cls_logits, bbox_deltas = self._forward_head(features, rois)

            labels = torch.cat(labels_list, dim=0)
            reg_targets = torch.cat(reg_targets_list, dim=0)

            loss_cls = F.cross_entropy(cls_logits, labels)

            pos_inds = torch.where(labels > 0)[0]
            if len(pos_inds) > 0:
                box_pred = bbox_deltas[pos_inds, labels[pos_inds]]
                loss_box = F.smooth_l1_loss(
                    box_pred, reg_targets[pos_inds], beta=1.0 / 9.0, reduction="sum"
                ) / max(len(pos_inds), 1)
            else:
                loss_box = cls_logits.sum() * 0.0

            return {"loss_cls": loss_cls, "loss_box": loss_box}

        outputs = []
        cls_logits, bbox_deltas = self._forward_head(features, proposals)
        probs = F.softmax(cls_logits, dim=1)

        offset = 0
        for i, props in enumerate(proposals):
            n = props.shape[0]
            img_scores = probs[offset:offset+n]
            img_deltas = bbox_deltas[offset:offset+n]
            offset += n

            h, w = image_sizes[i]
            boxes_all, scores_all, labels_all = [], [], []

            for c in range(1, self.num_classes):
                scores = img_scores[:, c]
                keep = scores > 0.05
                if keep.sum() == 0:
                    continue
                cls_boxes = decode_boxes(img_deltas[keep, c], props[keep])
                cls_boxes = clip_boxes_to_image(cls_boxes, (h, w))
                cls_scores = scores[keep]
                keep_nms = nms(cls_boxes, cls_scores, 0.3)
                cls_boxes = cls_boxes[keep_nms]
                cls_scores = cls_scores[keep_nms]
                cls_labels = torch.full((len(keep_nms),), c, dtype=torch.long, device=device)

                boxes_all.append(cls_boxes)
                scores_all.append(cls_scores)
                labels_all.append(cls_labels)

            if len(boxes_all) == 0:
                outputs.append({
                    "boxes": torch.zeros((0, 4), device=device),
                    "scores": torch.zeros((0,), device=device),
                    "labels": torch.zeros((0,), dtype=torch.long, device=device),
                })
            else:
                boxes_all = torch.cat(boxes_all, dim=0)
                scores_all = torch.cat(scores_all, dim=0)
                labels_all = torch.cat(labels_all, dim=0)
                topk = min(100, len(scores_all))
                order = torch.argsort(scores_all, descending=True)[:topk]
                outputs.append({
                    "boxes": boxes_all[order],
                    "scores": scores_all[order],
                    "labels": labels_all[order],
                })
        return outputs

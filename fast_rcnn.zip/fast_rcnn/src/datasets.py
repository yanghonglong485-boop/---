import os
import pickle
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import List, Dict

import torch
from torch.utils.data import Dataset
from PIL import Image
from pycocotools.coco import COCO
import torchvision.transforms.functional as TF

VOC_CLASSES = [
    "aeroplane", "bicycle", "bird", "boat", "bottle",
    "bus", "car", "cat", "chair", "cow",
    "diningtable", "dog", "horse", "motorbike", "person",
    "pottedplant", "sheep", "sofa", "train", "tvmonitor"
]

COCO_CAT_NAMES = [
    '__background__',
    'person', 'bicycle', 'car', 'motorcycle', 'airplane', 'bus', 'train', 'truck', 'boat',
    'traffic light', 'fire hydrant', 'stop sign', 'parking meter', 'bench', 'bird', 'cat', 'dog',
    'horse', 'sheep', 'cow', 'elephant', 'bear', 'zebra', 'giraffe', 'backpack', 'umbrella',
    'handbag', 'tie', 'suitcase', 'frisbee', 'skis', 'snowboard', 'sports ball', 'kite',
    'baseball bat', 'baseball glove', 'skateboard', 'surfboard', 'tennis racket', 'bottle',
    'wine glass', 'cup', 'fork', 'knife', 'spoon', 'bowl', 'banana', 'apple', 'sandwich',
    'orange', 'broccoli', 'carrot', 'hot dog', 'pizza', 'donut', 'cake', 'chair', 'couch',
    'potted plant', 'bed', 'dining table', 'toilet', 'tv', 'laptop', 'mouse', 'remote',
    'keyboard', 'cell phone', 'microwave', 'oven', 'toaster', 'sink', 'refrigerator', 'book',
    'clock', 'vase', 'scissors', 'teddy bear', 'hair drier', 'toothbrush'
]

IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]


def resize_image_boxes_proposals(image, boxes, proposals, min_size=480, max_size=800):
    w, h = image.size
    scale = min(min_size / min(h, w), max_size / max(h, w))
    if abs(scale - 1.0) > 1e-6:
        new_w, new_h = int(round(w * scale)), int(round(h * scale))
        image = image.resize((new_w, new_h), Image.BILINEAR)
        if boxes.numel() > 0:
            boxes = boxes * scale
        if proposals.numel() > 0:
            proposals = proposals * scale
    return image, boxes, proposals, scale


def image_to_tensor(image):
    x = TF.to_tensor(image)
    x = TF.normalize(x, mean=IMAGENET_MEAN, std=IMAGENET_STD)
    return x


def collate_fn(batch):
    return batch


class VOCFastRCNNDataset(Dataset):
    def __init__(self, voc_root: str, split: str, proposals_pkl: str, min_size=480, max_size=800):
        self.voc_root = Path(voc_root)
        self.split = split
        self.min_size = min_size
        self.max_size = max_size
        split_file = self.voc_root / "ImageSets" / "Main" / f"{split}.txt"
        self.ids = [x.strip() for x in split_file.read_text().splitlines() if x.strip()]
        self.class_to_idx = {c: i + 1 for i, c in enumerate(VOC_CLASSES)}
        self.idx_to_class = ['__background__'] + VOC_CLASSES
        with open(proposals_pkl, "rb") as f:
            self.proposals = pickle.load(f)
        self.num_classes = len(self.idx_to_class)

    def __len__(self):
        return len(self.ids)

    def _load_target(self, image_id):
        xml_path = self.voc_root / "Annotations" / f"{image_id}.xml"
        root = ET.parse(xml_path).getroot()
        boxes, labels = [], []
        for obj in root.findall("object"):
            name = obj.find("name").text.strip()
            bbox = obj.find("bndbox")
            xmin = float(bbox.find("xmin").text) - 1.0
            ymin = float(bbox.find("ymin").text) - 1.0
            xmax = float(bbox.find("xmax").text) - 1.0
            ymax = float(bbox.find("ymax").text) - 1.0
            if xmax <= xmin or ymax <= ymin:
                continue
            boxes.append([xmin, ymin, xmax, ymax])
            labels.append(self.class_to_idx[name])
        if len(boxes) == 0:
            boxes = torch.zeros((0, 4), dtype=torch.float32)
            labels = torch.zeros((0,), dtype=torch.long)
        else:
            boxes = torch.tensor(boxes, dtype=torch.float32)
            labels = torch.tensor(labels, dtype=torch.long)
        return boxes, labels

    def __getitem__(self, idx):
        image_id = self.ids[idx]
        img_path = self.voc_root / "JPEGImages" / f"{image_id}.jpg"
        image = Image.open(img_path).convert("RGB")
        boxes, labels = self._load_target(image_id)

        props = self.proposals[image_id]
        proposals = torch.tensor(props, dtype=torch.float32)
        image, boxes, proposals, scale = resize_image_boxes_proposals(
            image, boxes, proposals, self.min_size, self.max_size
        )
        image_tensor = image_to_tensor(image)
        target = {"boxes": boxes, "labels": labels, "image_id": image_id, "scale": scale}
        return image_tensor, proposals, target


class COCOFastRCNNDataset(Dataset):
    def __init__(self, coco_root: str, split: str, proposals_pkl: str, min_size=480, max_size=800):
        self.coco_root = Path(coco_root)
        self.image_root = self.coco_root / "images" / split
        self.ann_file = self.coco_root / "annotations" / "annotations" / f"instances_{split}.json"
        self.split = split
        self.min_size = min_size
        self.max_size = max_size
        self.coco = COCO(str(self.ann_file))
        self.image_ids = sorted(list(self.coco.imgs.keys()))
        cats = self.coco.loadCats(self.coco.getCatIds())
        cats = sorted(cats, key=lambda x: x["id"])
        self.cat_id_to_contiguous = {c["id"]: i + 1 for i, c in enumerate(cats)}
        self.contiguous_to_name = {i + 1: c["name"] for i, c in enumerate(cats)}
        self.idx_to_class = ['__background__'] + [self.contiguous_to_name[i] for i in range(1, len(cats) + 1)]
        with open(proposals_pkl, "rb") as f:
            self.proposals = pickle.load(f)
        self.num_classes = len(self.idx_to_class)

    def __len__(self):
        return len(self.image_ids)

    def _load_target(self, img_id):
        ann_ids = self.coco.getAnnIds(imgIds=img_id)
        anns = self.coco.loadAnns(ann_ids)
        boxes, labels = [], []
        for ann in anns:
            if ann.get("iscrowd", 0) == 1:
                continue
            x, y, w, h = ann["bbox"]
            if w <= 1 or h <= 1:
                continue
            boxes.append([x, y, x + w, y + h])
            labels.append(self.cat_id_to_contiguous[ann["category_id"]])
        if len(boxes) == 0:
            boxes = torch.zeros((0, 4), dtype=torch.float32)
            labels = torch.zeros((0,), dtype=torch.long)
        else:
            boxes = torch.tensor(boxes, dtype=torch.float32)
            labels = torch.tensor(labels, dtype=torch.long)
        return boxes, labels

    def __getitem__(self, idx):
        img_id = self.image_ids[idx]
        img_info = self.coco.loadImgs(img_id)[0]
        img_path = self.image_root / img_info["file_name"]
        image = Image.open(img_path).convert("RGB")
        boxes, labels = self._load_target(img_id)

        props = self.proposals[str(img_id)] if str(img_id) in self.proposals else self.proposals[img_id]
        proposals = torch.tensor(props, dtype=torch.float32)
        image, boxes, proposals, scale = resize_image_boxes_proposals(
            image, boxes, proposals, self.min_size, self.max_size
        )
        image_tensor = image_to_tensor(image)
        target = {"boxes": boxes, "labels": labels, "image_id": int(img_id), "scale": scale}
        return image_tensor, proposals, target


def build_dataset(dataset_name, root, split, proposals_pkl):
    if dataset_name == "voc":
        ds = VOCFastRCNNDataset(root, split, proposals_pkl)
    elif dataset_name == "coco":
        ds = COCOFastRCNNDataset(root, split, proposals_pkl)
    else:
        raise ValueError(f"unknown dataset: {dataset_name}")
    return ds

import argparse
import pickle
from pathlib import Path

import cv2
import torch
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from PIL import Image
from torchvision.ops import clip_boxes_to_image, nms

from src.datasets import (
    VOC_CLASSES,
    COCO_CAT_NAMES,
    image_to_tensor,
    resize_image_boxes_proposals,
)
from src.model import FastRCNN, decode_boxes, batch_images


def parse_args():
    parser = argparse.ArgumentParser("Fast R-CNN single image inference")
    parser.add_argument("--dataset", choices=["voc", "coco"], required=True)
    parser.add_argument("--weights", type=str, required=True)
    parser.add_argument("--image", type=str, required=True)

    # proposal 相关
    parser.add_argument("--topk", type=int, default=1000, help="Selective Search max proposals")
    parser.add_argument("--ss-mode", choices=["fast", "quality"], default="fast")
    parser.add_argument("--proposals-pkl", type=str, default="", help="可选：直接读取缓存 proposals 的 pkl")
    parser.add_argument("--image-id", type=str, default="", help="可选：pkl 中对应的 image_id；VOC 常为文件名 stem")

    # 后处理相关
    parser.add_argument("--pre-nms-thr", type=float, default=0.001, help="NMS 前的分类分数阈值")
    parser.add_argument("--score-thr", type=float, default=0.05, help="最终可视化显示阈值")
    parser.add_argument("--nms-thr", type=float, default=0.3)
    parser.add_argument("--max-dets", type=int, default=100)

    # 其他
    parser.add_argument("--device", type=str, default="auto", help="auto/cpu/cuda")
    parser.add_argument("--save-path", type=str, default="", help="可选：保存可视化结果")
    parser.add_argument("--hide-window", action="store_true", help="只保存，不弹窗")
    parser.add_argument("--debug-topk", type=int, default=20, help="打印前多少个 top 候选分数")
    return parser.parse_args()


def get_device(device_arg: str):
    if device_arg == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(device_arg)


def sanitize_state_dict(state_dict):
    new_state = {}
    for k, v in state_dict.items():
        if k.startswith("module."):
            k = k[len("module."):]
        new_state[k] = v
    return new_state


def load_model(weights_path: str, device: torch.device):
    ckpt = torch.load(weights_path, map_location="cpu")

    if isinstance(ckpt, dict) and "model" in ckpt:
        state_dict = ckpt["model"]
        num_classes = ckpt.get("num_classes", None)
    else:
        state_dict = ckpt
        num_classes = None

    state_dict = sanitize_state_dict(state_dict)

    if num_classes is None:
        # 兜底：从分类头权重反推类别数
        if "cls_score.weight" in state_dict:
            num_classes = state_dict["cls_score.weight"].shape[0]
        else:
            raise RuntimeError("无法从 checkpoint 中推断 num_classes")

    model = FastRCNN(num_classes=num_classes)
    model.load_state_dict(state_dict, strict=True)
    model.to(device)
    model.eval()
    return model, num_classes


def selective_search_boxes(image_path: Path, topk: int, mode: str = "fast"):
    if not hasattr(cv2, "ximgproc"):
        raise RuntimeError("cv2.ximgproc not found. Please install opencv-contrib-python")

    img = cv2.imread(str(image_path))
    if img is None:
        raise FileNotFoundError(f"无法读取图片: {image_path}")

    ss = cv2.ximgproc.segmentation.createSelectiveSearchSegmentation()
    ss.setBaseImage(img)
    if mode == "quality":
        ss.switchToSelectiveSearchQuality()
    else:
        ss.switchToSelectiveSearchFast()

    rects = ss.process()
    h, w = img.shape[:2]

    boxes = []
    seen = set()

    for x, y, bw, bh in rects:
        x1 = max(0, int(x))
        y1 = max(0, int(y))
        x2 = min(w - 1, int(x + bw - 1))
        y2 = min(h - 1, int(y + bh - 1))
        if x2 <= x1 or y2 <= y1:
            continue

        key = (x1, y1, x2, y2)
        if key in seen:
            continue
        seen.add(key)

        boxes.append([x1, y1, x2, y2])
        if len(boxes) >= topk:
            break

    if len(boxes) == 0:
        return torch.zeros((0, 4), dtype=torch.float32)

    return torch.tensor(boxes, dtype=torch.float32)


def load_cached_proposals(proposals_pkl: str, image_id: str, image_path: Path):
    with open(proposals_pkl, "rb") as f:
        cache = pickle.load(f)

    candidates = []
    if image_id:
        candidates.append(image_id)
    candidates.append(image_path.stem)

    # VOC 常见是字符串 key；COCO 有时是 int 或 str(int)
    try:
        candidates.append(int(image_path.stem))
    except Exception:
        pass

    found_key = None
    for key in candidates:
        if key in cache:
            found_key = key
            break
        if isinstance(key, int) and str(key) in cache:
            found_key = str(key)
            break
        if isinstance(key, str):
            try:
                ikey = int(key)
                if ikey in cache:
                    found_key = ikey
                    break
            except Exception:
                pass

    if found_key is None:
        keys_preview = list(cache.keys())[:10]
        raise KeyError(
            f"在 proposals pkl 中找不到 image_id。尝试过: {candidates}；示例 keys: {keys_preview}"
        )

    props = cache[found_key]
    proposals = torch.tensor(props, dtype=torch.float32)
    return proposals, found_key


def get_class_names(dataset: str, num_classes: int):
    if dataset == "voc":
        names = ["__background__"] + VOC_CLASSES
    else:
        names = COCO_CAT_NAMES

    if len(names) != num_classes:
        print(f"[警告] 类别名字数量({len(names)})与 checkpoint num_classes({num_classes})不一致")
    return names


def debug_print_roi_scores(probs: torch.Tensor, class_names, topk=20):
    # probs: [N, C]
    if probs.numel() == 0 or probs.shape[1] <= 1:
        print("[调试] 没有可用的分类概率")
        return

    fg_probs = probs[:, 1:]
    best_scores, best_labels = fg_probs.max(dim=1)
    order = torch.argsort(best_scores, descending=True)[: min(topk, len(best_scores))]

    print(f"[调试] ROI 前景最大分数 Top-{len(order)}：")
    for rank, idx in enumerate(order.tolist(), 1):
        score = best_scores[idx].item()
        label = best_labels[idx].item() + 1
        label_name = class_names[label] if label < len(class_names) else str(label)
        print(f"  {rank:02d}. roi={idx:4d}  score={score:.6f}  class={label:2d} ({label_name})")


def manual_inference(model, x, proposals, pre_nms_thr=0.001, nms_thr=0.3, max_dets=100):
    """
    手动拆开 forward 的推理后处理，避免被模型内部固定阈值卡死。
    """
    device = x.device
    batch, image_sizes = batch_images([x])
    features = model.backbone(batch)

    cls_logits, bbox_deltas = model._forward_head(features, [proposals])
    probs = torch.softmax(cls_logits, dim=1)

    h, w = image_sizes[0]
    boxes_all, scores_all, labels_all = [], [], []

    for c in range(1, model.num_classes):
        scores = probs[:, c]
        keep = scores > pre_nms_thr
        if keep.sum().item() == 0:
            continue

        cls_boxes = decode_boxes(bbox_deltas[keep, c], proposals[keep])
        cls_boxes = clip_boxes_to_image(cls_boxes, (h, w))
        cls_scores = scores[keep]

        keep_nms = nms(cls_boxes, cls_scores, nms_thr)
        cls_boxes = cls_boxes[keep_nms]
        cls_scores = cls_scores[keep_nms]
        cls_labels = torch.full((len(keep_nms),), c, dtype=torch.long, device=device)

        boxes_all.append(cls_boxes)
        scores_all.append(cls_scores)
        labels_all.append(cls_labels)

    if len(boxes_all) == 0:
        outputs = {
            "boxes": torch.zeros((0, 4), device=device),
            "scores": torch.zeros((0,), device=device),
            "labels": torch.zeros((0,), dtype=torch.long, device=device),
        }
    else:
        boxes_all = torch.cat(boxes_all, dim=0)
        scores_all = torch.cat(scores_all, dim=0)
        labels_all = torch.cat(labels_all, dim=0)

        order = torch.argsort(scores_all, descending=True)[: min(max_dets, len(scores_all))]
        outputs = {
            "boxes": boxes_all[order],
            "scores": scores_all[order],
            "labels": labels_all[order],
        }

    return outputs, probs


def draw_results(image, boxes, scores, labels, class_names, score_thr=0.05):
    fig, ax = plt.subplots(figsize=(12, 8))
    ax.imshow(image)

    shown = 0
    for box, score, label in zip(boxes, scores, labels):
        score_val = float(score.item())
        if score_val < score_thr:
            continue

        x1, y1, x2, y2 = box.tolist()
        label_id = int(label.item())
        label_name = class_names[label_id] if label_id < len(class_names) else str(label_id)

        rect = patches.Rectangle(
            (x1, y1),
            x2 - x1,
            y2 - y1,
            fill=False,
            linewidth=2,
        )
        ax.add_patch(rect)
        ax.text(
            x1,
            max(0, y1 - 2),
            f"{label_name}: {score_val:.3f}",
            fontsize=10,
            color="white",
            bbox=dict(facecolor="black", alpha=0.7, pad=1),
        )
        shown += 1

    ax.set_axis_off()
    plt.tight_layout()
    return fig, shown


def main():
    args = parse_args()
    device = get_device(args.device)

    print("=" * 80)
    print("单图推理开始")
    print(f"[信息] device           : {device}")
    print(f"[信息] dataset          : {args.dataset}")
    print(f"[信息] weights          : {args.weights}")
    print(f"[信息] image            : {args.image}")
    print(f"[信息] pre_nms_thr      : {args.pre_nms_thr}")
    print(f"[信息] score_thr        : {args.score_thr}")
    print(f"[信息] nms_thr          : {args.nms_thr}")
    print(f"[信息] max_dets         : {args.max_dets}")
    print("=" * 80)

    model, num_classes = load_model(args.weights, device)
    class_names = get_class_names(args.dataset, num_classes)

    image_path = Path(args.image)
    if not image_path.exists():
        raise FileNotFoundError(f"图片不存在: {image_path}")

    image = Image.open(image_path).convert("RGB")

    # 1) 取 proposals
    if args.proposals_pkl:
        proposals, found_key = load_cached_proposals(args.proposals_pkl, args.image_id, image_path)
        print(f"[信息] 使用缓存 proposals: {args.proposals_pkl}")
        print(f"[信息] 命中 image_id      : {found_key}")
    else:
        proposals = selective_search_boxes(image_path, args.topk, args.ss_mode)
        print(f"[信息] 使用在线 Selective Search ({args.ss_mode})")

    print(f"[信息] proposals 数量    : {len(proposals)}")
    if len(proposals) == 0:
        raise RuntimeError("没有生成任何 proposals，无法推理")

    # 2) resize + tensor
    dummy_boxes = torch.zeros((0, 4), dtype=torch.float32)
    resized_image, _, proposals_resized, scale = resize_image_boxes_proposals(
        image, dummy_boxes, proposals
    )
    x = image_to_tensor(resized_image).to(device)
    proposals_resized = proposals_resized.to(device)

    print(f"[信息] resize scale      : {scale:.6f}")
    print(f"[信息] resized image     : {resized_image.size}")

    # 3) 手动推理
    with torch.no_grad():
        outputs, probs = manual_inference(
            model=model,
            x=x,
            proposals=proposals_resized,
            pre_nms_thr=args.pre_nms_thr,
            nms_thr=args.nms_thr,
            max_dets=args.max_dets,
        )

    debug_print_roi_scores(probs.detach().cpu(), class_names, topk=args.debug_topk)

    boxes = outputs["boxes"].detach().cpu()
    scores = outputs["scores"].detach().cpu()
    labels = outputs["labels"].detach().cpu()

    # 映射回原图坐标
    boxes = boxes / scale

    print(f"[信息] NMS 后检测框数量   : {len(boxes)}")
    if len(scores) > 0:
        print(f"[信息] 最高检测分数      : {scores.max().item():.6f}")
    else:
        print("[信息] 没有任何检测框")

    shown_mask = scores >= args.score_thr
    shown_num = int(shown_mask.sum().item()) if len(scores) > 0 else 0
    print(f"[信息] 最终显示框数量    : {shown_num}")

    fig, shown = draw_results(
        image=image,
        boxes=boxes,
        scores=scores,
        labels=labels,
        class_names=class_names,
        score_thr=args.score_thr,
    )

    # 如果一个都不显示，额外给出提示
    if shown == 0:
        print("[提示] 当前 score_thr 下没有可显示结果。")
        print("[提示] 先看上面的 ROI Top 分数和最高检测分数，再决定是否调低 pre_nms_thr / score_thr。")

    if args.save_path:
        save_path = Path(args.save_path)
        save_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=200, bbox_inches="tight", pad_inches=0.02)
        print(f"[信息] 结果已保存到      : {save_path}")

    if not args.hide_window:
        plt.show()
    else:
        plt.close(fig)


if __name__ == "__main__":
    main()
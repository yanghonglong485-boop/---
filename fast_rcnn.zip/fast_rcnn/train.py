
import argparse
import logging
import os
import sys
from pathlib import Path

import torch
import torch.distributed as dist
import torch.multiprocessing as mp
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader, DistributedSampler
from tqdm import tqdm

from src.datasets import build_dataset, collate_fn
from src.model import FastRCNN


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", choices=["voc", "coco"], required=True)
    parser.add_argument("--root", type=str, required=True)
    parser.add_argument("--train-split", type=str, required=True)
    parser.add_argument("--val-split", type=str, required=True)
    parser.add_argument("--train-proposals", type=str, required=True)
    parser.add_argument("--val-proposals", type=str, required=True)
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--batch-size", type=int, default=2)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight-decay", type=float, default=5e-4)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--save-dir", type=str, default="checkpoints/exp")
    parser.add_argument("--device", type=str, default="cuda")
    parser.add_argument("--backbone-weights", type=str, default="")
    parser.add_argument("--ddp", action="store_true")
    parser.add_argument("--gpus", type=int, default=1)
    parser.add_argument("--sync-file", type=str, default=".ddp_sync")
    parser.add_argument("--amp", action="store_true", default=True)
    return parser.parse_args()


def build_logger(save_dir: Path, rank: int = 0):
    logger = logging.getLogger(f"train_rank{rank}")
    logger.setLevel(logging.INFO)
    logger.propagate = False

    for h in list(logger.handlers):
        logger.removeHandler(h)

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%H:%M:%S",
    )

    if rank == 0:
        save_dir.mkdir(parents=True, exist_ok=True)

        stream_handler = logging.StreamHandler(sys.stdout)
        stream_handler.setFormatter(formatter)
        logger.addHandler(stream_handler)

        file_handler = logging.FileHandler(save_dir / "train.log", encoding="utf-8")
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    else:
        logger.addHandler(logging.NullHandler())

    return logger


@torch.no_grad()
def validate(model, loader, device, amp_enabled, rank=0):
    model.eval()
    total = 0.0
    n = 0

    pbar = tqdm(
        loader,
        desc="val",
        leave=False,
        dynamic_ncols=True,
        ascii=True,
        disable=(rank != 0),
    )

    for batch in pbar:
        images, proposals, targets = zip(*batch)
        images = [x.to(device, non_blocking=True) for x in images]
        proposals = [x.to(device, non_blocking=True) for x in proposals]
        targets = [
            {k: (v.to(device, non_blocking=True) if torch.is_tensor(v) else v) for k, v in t.items()}
            for t in targets
        ]

        model.train()
        with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=amp_enabled and device.type == "cuda"):
            losses = model(images, proposals, targets)
            loss = sum(losses.values())
        model.eval()

        total += loss.item()
        n += 1

        if rank == 0:
            pbar.set_postfix(val_loss=f"{loss.item():.4f}")

    pbar.close()
    return total / max(n, 1)


def train_one_epoch(model, loader, optimizer, scaler, device, epoch, epochs, amp_enabled, rank=0, is_ddp=False):
    model.train()

    running_total = 0.0
    running_cls = 0.0
    running_box = 0.0
    n = 0

    pbar = tqdm(
        loader,
        desc=f"train epoch {epoch}/{epochs}",
        leave=False,
        dynamic_ncols=True,
        ascii=True,
        disable=(is_ddp and rank != 0),
    )

    for batch in pbar:
        images, proposals, targets = zip(*batch)
        images = [x.to(device, non_blocking=True) for x in images]
        proposals = [x.to(device, non_blocking=True) for x in proposals]
        targets = [
            {k: (v.to(device, non_blocking=True) if torch.is_tensor(v) else v) for k, v in t.items()}
            for t in targets
        ]

        optimizer.zero_grad(set_to_none=True)

        with torch.autocast(device_type="cuda", dtype=torch.float16, enabled=amp_enabled and device.type == "cuda"):
            losses = model(images, proposals, targets)
            loss_cls = losses["loss_cls"]
            loss_box = losses["loss_box"]
            loss = loss_cls + loss_box

        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()

        running_total += loss.item()
        running_cls += loss_cls.item()
        running_box += loss_box.item()
        n += 1

        if (not is_ddp) or rank == 0:
            pbar.set_postfix(
                loss=f"{loss.item():.4f}",
                cls=f"{loss_cls.item():.4f}",
                box=f"{loss_box.item():.4f}",
                avg=f"{running_total / max(n, 1):.4f}",
            )

    pbar.close()
    return {
        "loss": running_total,
        "cls": running_cls,
        "box": running_box,
        "steps": n,
    }


def setup_ddp(rank, world_size, sync_file):
    os.environ["USE_LIBUV"] = "0"
    store = dist.FileStore(sync_file, world_size)

    dist.init_process_group(
        backend="gloo",
        store=store,
        rank=rank,
        world_size=world_size,
    )
    torch.cuda.set_device(rank)


def cleanup_ddp():
    if dist.is_initialized():
        dist.destroy_process_group()


def ddp_worker(rank, world_size, args):
    setup_ddp(rank, world_size, args.sync_file)

    save_dir = Path(args.save_dir)
    logger = build_logger(save_dir, rank)

    device = torch.device(f"cuda:{rank}")
    if device.type == "cuda":
        torch.backends.cudnn.benchmark = True

    train_ds = build_dataset(args.dataset, args.root, args.train_split, args.train_proposals)
    val_ds = build_dataset(args.dataset, args.root, args.val_split, args.val_proposals)

    train_sampler = DistributedSampler(
        train_ds,
        num_replicas=world_size,
        rank=rank,
        shuffle=True,
        drop_last=False,
    )

    train_loader = DataLoader(
        train_ds,
        batch_size=args.batch_size,
        sampler=train_sampler,
        shuffle=False,
        num_workers=args.num_workers,
        collate_fn=collate_fn,
        pin_memory=(device.type == "cuda"),
        persistent_workers=(args.num_workers > 0),
    )

    if rank == 0:
        val_loader = DataLoader(
            val_ds,
            batch_size=args.batch_size,
            shuffle=False,
            num_workers=args.num_workers,
            collate_fn=collate_fn,
            pin_memory=(device.type == "cuda"),
            persistent_workers=(args.num_workers > 0),
        )
        logger.info(
            f"DDP start | dataset={args.dataset} | train_split={args.train_split} | "
            f"val_split={args.val_split} | gpus={world_size} | per_gpu_batch={args.batch_size}"
        )
        logger.info(
            f"train_samples={len(train_ds)} | val_samples={len(val_ds)} | "
            f"backbone_weights={'yes' if args.backbone_weights else 'no'}"
        )
    else:
        val_loader = None

    model = FastRCNN(
        num_classes=train_ds.num_classes,
        backbone_weights=args.backbone_weights,
    ).to(device)

    model = DDP(model, device_ids=[rank], output_device=rank)

    optimizer = torch.optim.SGD(
        model.parameters(),
        lr=args.lr,
        momentum=0.9,
        weight_decay=args.weight_decay,
    )
    scheduler = torch.optim.lr_scheduler.StepLR(
        optimizer,
        step_size=max(args.epochs // 2, 1),
        gamma=0.1,
    )
    scaler = torch.amp.GradScaler("cuda", enabled=(args.amp and device.type == "cuda"))

    best_val = float("inf")

    for epoch in range(1, args.epochs + 1):
        train_sampler.set_epoch(epoch)

        stats = train_one_epoch(
            model=model,
            loader=train_loader,
            optimizer=optimizer,
            scaler=scaler,
            device=device,
            epoch=epoch,
            epochs=args.epochs,
            amp_enabled=args.amp,
            rank=rank,
            is_ddp=True,
        )

        scheduler.step()

        stat_tensor = torch.tensor(
            [stats["loss"], stats["cls"], stats["box"], stats["steps"]],
            dtype=torch.float64,
            device=device,
        )
        dist.all_reduce(stat_tensor, op=dist.ReduceOp.SUM)

        train_loss = stat_tensor[0].item() / max(stat_tensor[3].item(), 1.0)
        train_cls = stat_tensor[1].item() / max(stat_tensor[3].item(), 1.0)
        train_box = stat_tensor[2].item() / max(stat_tensor[3].item(), 1.0)

        dist.barrier()

        if rank == 0:
            val_loss = validate(model.module, val_loader, device, amp_enabled=args.amp, rank=rank)

            ckpt = {
                "epoch": epoch,
                "model": model.module.state_dict(),
                "optimizer": optimizer.state_dict(),
                "num_classes": train_ds.num_classes,
                "dataset": args.dataset,
            }
            torch.save(ckpt, save_dir / "last.pt")
            if val_loss < best_val:
                best_val = val_loss
                torch.save(ckpt, save_dir / "best.pt")

            current_lr = optimizer.param_groups[0]["lr"]
            logger.info(
                f"[epoch {epoch:03d}/{args.epochs:03d}] "
                f"lr={current_lr:.6f} | "
                f"train_loss={train_loss:.4f} | train_cls={train_cls:.4f} | train_box={train_box:.4f} | "
                f"val_loss={val_loss:.4f} | best_val={best_val:.4f}"
            )

        dist.barrier()

    cleanup_ddp()


def single_gpu_main(args):
    save_dir = Path(args.save_dir)
    logger = build_logger(save_dir, rank=0)

    device = torch.device("cuda" if args.device == "cuda" and torch.cuda.is_available() else "cpu")
    if device.type == "cuda":
        torch.backends.cudnn.benchmark = True

    train_ds = build_dataset(args.dataset, args.root, args.train_split, args.train_proposals)
    val_ds = build_dataset(args.dataset, args.root, args.val_split, args.val_proposals)

    train_loader = DataLoader(
        train_ds,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        collate_fn=collate_fn,
        pin_memory=(device.type == "cuda"),
        persistent_workers=(args.num_workers > 0),
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        collate_fn=collate_fn,
        pin_memory=(device.type == "cuda"),
        persistent_workers=(args.num_workers > 0),
    )

    logger.info(
        f"Single GPU start | dataset={args.dataset} | train_split={args.train_split} | val_split={args.val_split}"
    )
    logger.info(
        f"train_samples={len(train_ds)} | val_samples={len(val_ds)} | batch={args.batch_size} | "
        f"backbone_weights={'yes' if args.backbone_weights else 'no'}"
    )

    model = FastRCNN(
        num_classes=train_ds.num_classes,
        backbone_weights=args.backbone_weights,
    ).to(device)

    optimizer = torch.optim.SGD(
        model.parameters(),
        lr=args.lr,
        momentum=0.9,
        weight_decay=args.weight_decay,
    )
    scheduler = torch.optim.lr_scheduler.StepLR(
        optimizer,
        step_size=max(args.epochs // 2, 1),
        gamma=0.1,
    )
    scaler = torch.amp.GradScaler("cuda", enabled=(args.amp and device.type == "cuda"))

    best_val = float("inf")

    for epoch in range(1, args.epochs + 1):
        stats = train_one_epoch(
            model=model,
            loader=train_loader,
            optimizer=optimizer,
            scaler=scaler,
            device=device,
            epoch=epoch,
            epochs=args.epochs,
            amp_enabled=args.amp,
            rank=0,
            is_ddp=False,
        )

        scheduler.step()

        train_loss = stats["loss"] / max(stats["steps"], 1)
        train_cls = stats["cls"] / max(stats["steps"], 1)
        train_box = stats["box"] / max(stats["steps"], 1)

        val_loss = validate(model, val_loader, device, amp_enabled=args.amp, rank=0)

        ckpt = {
            "epoch": epoch,
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "num_classes": train_ds.num_classes,
            "dataset": args.dataset,
        }
        torch.save(ckpt, save_dir / "last.pt")
        if val_loss < best_val:
            best_val = val_loss
            torch.save(ckpt, save_dir / "best.pt")

        current_lr = optimizer.param_groups[0]["lr"]
        logger.info(
            f"[epoch {epoch:03d}/{args.epochs:03d}] "
            f"lr={current_lr:.6f} | "
            f"train_loss={train_loss:.4f} | train_cls={train_cls:.4f} | train_box={train_box:.4f} | "
            f"val_loss={val_loss:.4f} | best_val={best_val:.4f}"
        )


def main():
    args = parse_args()

    if args.ddp:
        mp.freeze_support()

        sync_path = Path(args.sync_file)
        if sync_path.exists():
            try:
                sync_path.unlink()
            except Exception:
                pass

        mp.spawn(
            ddp_worker,
            args=(args.gpus, args),
            nprocs=args.gpus,
            join=True,
        )
    else:
        single_gpu_main(args)


if __name__ == "__main__":
    main()

import os
import sys
from pathlib import Path

PROJECT_ROOT = r"D:\CWC\deeplearning\shiyan2"
os.chdir(PROJECT_ROOT)

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

Path("checkpoints").mkdir(exist_ok=True)

from train import main as train_main

if __name__ == "__main__":
    sys.argv = [
        "train.py",
        "--dataset", "voc",
        "--root", r"D:\CWC\deeplearning\shiyan2\data\voc\VOCdevkit\VOC2012",
        "--train-split", "train",
        "--val-split", "val",
        "--train-proposals", r"caches\voc12_train_ss.pkl",
        "--val-proposals", r"caches\voc12_val_ss.pkl",
        "--epochs", "20",

        # 这里是“每张卡”的 batch size
        "--batch-size", "8",

        "--lr", "0.001",
        "--num-workers", "0",
        "--save-dir", r"checkpoints\voc12_ddp",

        "--backbone-weights", r"C:\Users\Cheng Wen Can\.cache\torch\hub\checkpoints\resnet50-11ad3fa6.pth",

        "--ddp",
        "--gpus", "2",
        "--sync-file", r"D:\CWC\deeplearning\shiyan2\.ddp_voc_sync",
    ]

    train_main()
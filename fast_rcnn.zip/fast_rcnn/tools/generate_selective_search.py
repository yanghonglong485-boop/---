import argparse
import pickle
from pathlib import Path
import xml.etree.ElementTree as ET

import cv2
import numpy as np
from tqdm import tqdm
from pycocotools.coco import COCO


VOC_CLASSES = [
    "aeroplane", "bicycle", "bird", "boat", "bottle",
    "bus", "car", "cat", "chair", "cow",
    "diningtable", "dog", "horse", "motorbike", "person",
    "pottedplant", "sheep", "sofa", "train", "tvmonitor"
]


def selective_search_boxes(image_path, topk):
    img = cv2.imread(str(image_path))
    if img is None:
        raise RuntimeError(f"cannot read image: {image_path}")
    ss = cv2.ximgproc.segmentation.createSelectiveSearchSegmentation()
    ss.setBaseImage(img)
    ss.switchToSelectiveSearchFast()
    rects = ss.process()
    boxes = []
    seen = set()
    h, w = img.shape[:2]
    for x, y, bw, bh in rects:
        x1 = max(0, x)
        y1 = max(0, y)
        x2 = min(w - 1, x + bw - 1)
        y2 = min(h - 1, y + bh - 1)
        if x2 <= x1 or y2 <= y1:
            continue
        key = (int(x1), int(y1), int(x2), int(y2))
        if key in seen:
            continue
        seen.add(key)
        boxes.append([x1, y1, x2, y2])
        if len(boxes) >= topk:
            break
    return boxes


def build_voc_records(voc_root, split):
    voc_root = Path(voc_root)
    ids = [x.strip() for x in (voc_root / "ImageSets" / "Main" / f"{split}.txt").read_text().splitlines() if x.strip()]
    for image_id in ids:
        yield image_id, voc_root / "JPEGImages" / f"{image_id}.jpg"


def build_coco_records(coco_img_root, coco_ann):
    coco = COCO(str(coco_ann))
    for img_id in sorted(coco.imgs.keys()):
        info = coco.loadImgs(img_id)[0]
        yield str(img_id), Path(coco_img_root) / info["file_name"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", choices=["voc", "coco"], required=True)
    parser.add_argument("--voc-root", type=str, default=None)
    parser.add_argument("--split", type=str, default=None)
    parser.add_argument("--coco-img-root", type=str, default=None)
    parser.add_argument("--coco-ann", type=str, default=None)
    parser.add_argument("--out", type=str, required=True)
    parser.add_argument("--topk", type=int, default=2000)
    args = parser.parse_args()

    if not hasattr(cv2, "ximgproc"):
        raise RuntimeError("cv2.ximgproc not found. Please install opencv-contrib-python")

    if args.dataset == "voc":
        records = list(build_voc_records(args.voc_root, args.split))
    else:
        records = list(build_coco_records(args.coco_img_root, args.coco_ann))

    proposals = {}
    for image_id, image_path in tqdm(records, total=len(records)):
        boxes = selective_search_boxes(image_path, args.topk)
        proposals[image_id] = boxes

    with open(args.out, "wb") as f:
        pickle.dump(proposals, f)

    print(f"saved proposals -> {args.out}, images={len(proposals)}")


if __name__ == "__main__":
    main()

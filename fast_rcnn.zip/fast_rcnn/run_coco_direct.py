import os
import sys
from pathlib import Path

PROJECT_ROOT = r"D:\CWC\deeplearning\shiyan2"
os.chdir(PROJECT_ROOT)

if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

Path("caches").mkdir(exist_ok=True)
Path("checkpoints").mkdir(exist_ok=True)

print("当前工作目录：", os.getcwd())


def generate_coco_proposals():
    from tools.generate_selective_search import main as ss_main

    # train2017
    sys.argv = [
        "generate_selective_search.py",
        "--dataset", "coco",
        "--coco-img-root", r"D:\CWC\deeplearning\shiyan2\data\coco\images\train2017",
        "--coco-ann", r"D:\CWC\deeplearning\shiyan2\data\coco\annotations\annotations\instances_train2017.json",
        "--out", r"caches\coco17_train_ss.pkl",
        "--topk", "2000",
    ]
    print("\n========== 生成 COCO train proposals ==========")
    ss_main()

    # val2017
    sys.argv = [
        "generate_selective_search.py",
        "--dataset", "coco",
        "--coco-img-root", r"D:\CWC\deeplearning\shiyan2\data\coco\images\val2017",
        "--coco-ann", r"D:\CWC\deeplearning\shiyan2\data\coco\annotations\annotations\instances_val2017.json",
        "--out", r"caches\coco17_val_ss.pkl",
        "--topk", "1000",
    ]
    print("\n========== 生成 COCO val proposals ==========")
    ss_main()


def train_coco():
    from train import main as train_main

    sys.argv = [
        "train.py",
        "--dataset", "coco",
        "--root", r"D:\CWC\deeplearning\shiyan2\data\coco",
        "--train-split", "train2017",
        "--val-split", "val2017",
        "--train-proposals", r"caches\coco17_train_ss.pkl",
        "--val-proposals", r"caches\coco17_val_ss.pkl",
        "--epochs", "12",
        "--batch-size", "2",
        "--lr", "0.001",
        "--num-workers", "4",
        "--save-dir", r"checkpoints\coco17",
    ]
    print("\n========== 开始训练 COCO Fast R-CNN ==========")
    train_main()


def infer_coco():
    from infer import main as infer_main

    sys.argv = [
        "infer.py",
        "--dataset", "coco",
        "--weights", r"checkpoints\coco17\best.pt",
        "--image", r"D:\CWC\deeplearning\shiyan2\data\coco\images\val2017\000000000139.jpg",
        "--score-thr", "0.5",
        "--topk", "1000",
    ]
    print("\n========== COCO 单图推理 ==========")
    infer_main()


if __name__ == "__main__":
    generate_coco_proposals()
    train_coco()
    infer_coco()
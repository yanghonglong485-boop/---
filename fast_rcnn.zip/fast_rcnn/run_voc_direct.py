import os
import sys
from pathlib import Path

# 固定项目根目录
PROJECT_ROOT = r"D:\CWC\deeplearning\shiyan2"
os.chdir(PROJECT_ROOT)

# 确保当前目录在 import 路径里
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# 创建输出目录
Path("caches").mkdir(exist_ok=True)
Path("checkpoints").mkdir(exist_ok=True)

print("当前工作目录：", os.getcwd())


def generate_voc_proposals():
    from tools.generate_selective_search import main as ss_main

    # 生成 train proposals
    # sys.argv = [
    #     "generate_selective_search.py",
    #     "--dataset", "voc",
    #     "--voc-root", r"D:\CWC\deeplearning\shiyan2\data\voc\VOCdevkit\VOC2012",
    #     "--split", "train",
    #     "--out", r"caches\voc12_train_ss.pkl",
    #     "--topk", "2000",
    # ]
    # print("\n========== 生成 VOC train proposals ==========")
    # ss_main()

    # 生成 val proposals
    sys.argv = [
        "generate_selective_search.py",
        "--dataset", "voc",
        "--voc-root", r"D:\CWC\deeplearning\shiyan2\data\voc\VOCdevkit\VOC2012",
        "--split", "val",
        "--out", r"caches\voc12_val_ss.pkl",
        "--topk", "1000",
    ]
    print("\n========== 生成 VOC val proposals ==========")
    ss_main()


def train_voc():
    from train import main as train_main

    sys.argv = [
        "train.py",
        "--dataset", "voc",
        "--root", r"D:\CWC\deeplearning\shiyan2\data\voc\VOCdevkit\VOC2012",
        "--train-split", "train",
        "--val-split", "val",
        "--train-proposals", r"caches\voc12_train_ss.pkl",
        "--val-proposals", r"caches\voc12_val_ss.pkl",
        "--epochs", "20",
        "--batch-size", "2",
        "--lr", "0.001",
        "--num-workers", "4",
        "--save-dir", r"checkpoints\voc12",
    ]
    print("\n========== 开始训练 VOC Fast R-CNN ==========")
    train_main()


def infer_voc():
    from infer import main as infer_main

    sys.argv = [
        "infer.py",
        "--dataset", "voc",
        "--weights", r"checkpoints\voc12_ddp\best.pt",
        "--image", r"D:\CWC\deeplearning\shiyan2\data\voc\VOCdevkit\VOC2012\JPEGImages\2007_007815.jpg",

        "--score-thr", "0.05",
        "--pre-nms-thr", "0.001",
        "--max-dets", "100",
    ]
    print("\n========== VOC 单图推理 ==========")
    infer_main()


if __name__ == "__main__":
    # generate_voc_proposals()
    # train_voc()
    infer_voc()
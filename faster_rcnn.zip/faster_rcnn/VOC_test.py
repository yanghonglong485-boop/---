import os
import torch
import torchvision
from pathlib import Path
from PIL import Image
from torchvision.transforms import ToTensor
from torchvision.models.detection import fasterrcnn_resnet50_fpn_v2
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
import matplotlib.pyplot as plt
import matplotlib.patches as patches

# ===================== 配置 =====================
DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
NUM_CLASSES = 21
MODEL_PATH = Path("./faster_rcnn_result_voc/faster_rcnn_voc.pth")
TEST_IMAGE_DIR = Path("./VOCdevkit/VOC2012/JPEGImages")  # 测试图目录
SAVE_RESULT = Path("./test_results")
SAVE_RESULT.mkdir(exist_ok=True)

# VOC 类别（必须和训练一致）
CLASS_NAMES = [
    'aeroplane','bicycle','bird','boat','bottle','bus','car','cat',
    'chair','cow','diningtable','dog','horse','motorbike','person',
    'pottedplant','sheep','sofa','train','tvmonitor'
]

# ===================== 加载模型 =====================
def load_trained_model():
    model = fasterrcnn_resnet50_fpn_v2(weights=None)
    in_feat = model.roi_heads.box_predictor.cls_score.in_features
    model.roi_heads.box_predictor = FastRCNNPredictor(in_feat, NUM_CLASSES)
    model.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE))
    model.to(DEVICE)
    model.eval()
    return model

# ===================== 单张图预测 =====================
def predict_one_image(model, img_path, score_thresh=0.5):
    img = Image.open(img_path).convert("RGB")
    transform = ToTensor()
    img_tensor = transform(img).to(DEVICE)

    with torch.no_grad():
        pred = model([img_tensor])[0]

    # 过滤低置信度
    boxes = pred["boxes"].cpu().numpy()
    scores = pred["scores"].cpu().numpy()
    labels = pred["labels"].cpu().numpy()

    keep = scores >= score_thresh
    boxes = boxes[keep]
    scores = scores[keep]
    labels = labels[keep]

    return img, boxes, scores, labels

# ===================== 画框 + 保存 =====================
def draw_and_save(img, boxes, scores, labels, save_path):
    plt.figure(figsize=(12, 8))
    plt.imshow(img)
    ax = plt.gca()

    for box, score, lbl in zip(boxes, scores, labels):
        x1, y1, x2, y2 = box
        w = x2 - x1
        h = y2 - y1
        cls_name = CLASS_NAMES[lbl - 1]  # 标签从1开始

        rect = patches.Rectangle((x1, y1), w, h, linewidth=2, edgecolor="red", fill=False)
        ax.add_patch(rect)
        ax.text(x1, y1 - 8, f"{cls_name} {score:.2f}", color="white",
                bbox=dict(facecolor="red", alpha=0.7))

    plt.axis("off")
    plt.tight_layout()
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()

# ===================== 批量测试文件夹所有图片 =====================
if __name__ == "__main__":
    print("加载模型...")
    model = load_trained_model()
    print("模型加载完成！")

    # 遍历测试图片
    img_paths = list(TEST_IMAGE_DIR.glob("*.jpg"))
    if not img_paths:
        print(f"未在 {TEST_IMAGE_DIR} 找到图片！请检查数据集路径")
    else:
        print(f"找到 {len(img_paths)} 张测试图，开始预测...")

    for i, img_path in enumerate(img_paths[:20]):  # 只测前20张，避免太多
        print(f"正在处理: {img_path.name}")
        img, boxes, scores, labels = predict_one_image(model, img_path)
        save_path = SAVE_RESULT / f"test_{img_path.stem}.jpg"
        draw_and_save(img, boxes, scores, labels, save_path)

    print(f"\n测试完成！结果保存在: {SAVE_RESULT.absolute()}")
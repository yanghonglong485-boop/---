import os
import torch
import torchvision
from pathlib import Path
from tqdm import tqdm
from torch.utils.data import DataLoader
from torchvision.models.detection import fasterrcnn_resnet50_fpn_v2
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
from torchvision.datasets import CocoDetection
from torchvision.transforms import ToTensor
import warnings
warnings.filterwarnings("ignore")

# ===================== 配置 =====================
DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
ROOT = "."
EPOCHS = 12
BATCH = 2
NUM_CLASSES = 91
SAVE = Path("./faster_rcnn_coco_result")
SAVE.mkdir(exist_ok=True)

# ===================== COCO 数据集 =====================
class COCOFull(CocoDetection):
    def __init__(self, img_root, ann_file):
        super().__init__(img_root, ann_file, transform=ToTensor())

    def __getitem__(self, idx):
        img, target = super().__getitem__(idx)
        boxes = []
        labels = []
        for obj in target:
            x, y, w, h = obj["bbox"]
            boxes.append([x, y, x + w, y + h])
            labels.append(obj["category_id"])
        return img, {
            "boxes": torch.tensor(boxes, dtype=torch.float32),
            "labels": torch.tensor(labels, dtype=torch.int64)
        }

# ===================== 模型 =====================
def get_model():
    model = fasterrcnn_resnet50_fpn_v2(weights="DEFAULT")
    in_feat = model.roi_heads.box_predictor.cls_score.in_features
    model.roi_heads.box_predictor = FastRCNNPredictor(in_feat, NUM_CLASSES)
    return model.to(DEVICE)

# ===================== 训练 =====================
def train_epoch(model, loader, opt):
    model.train()
    total_loss = 0.0
    for imgs, targets in tqdm(loader, desc="Training"):
        imgs = [img.to(DEVICE) for img in imgs]
        targets = [{k: v.to(DEVICE) for k, v in t.items()} for t in targets]
        loss_dict = model(imgs, targets)
        loss = sum(loss_dict.values())
        opt.zero_grad()
        loss.backward()
        opt.step()
        total_loss += loss.item()
    return total_loss / len(loader)

# ===================== 主程序 =====================
if __name__ == "__main__":
    train_img = "./coco/train2017"
    train_ann = "./coco/annotations/instances_train2017.json"

    train_ds = COCOFull(train_img, train_ann)
    train_loader = DataLoader(
        train_ds, BATCH, shuffle=True,
        collate_fn=lambda x: tuple(zip(*x))
    )

    model = get_model()
    opt = torch.optim.Adam(model.parameters(), lr=1e-4)

    print("开始 COCO 全量训练...")
    for epoch in range(EPOCHS):
        loss = train_epoch(model, train_loader, opt)
        print(f"Epoch {epoch+1}/{EPOCHS} | Loss: {loss:.4f}")

    torch.save(model.state_dict(), SAVE / "faster_rcnn_coco.pth")
    print("训练完成！模型已保存至:", SAVE / "faster_rcnn_coco.pth")
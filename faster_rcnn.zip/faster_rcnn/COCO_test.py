import torch
import torchvision
import numpy as np
import pandas as pd
from pathlib import Path
from tqdm import tqdm
from torch.utils.data import DataLoader
from torchvision.models.detection import fasterrcnn_resnet50_fpn_v2
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
from torchvision.datasets import CocoDetection
from torchvision.transforms import ToTensor
from torchmetrics.detection import MeanAveragePrecision
import warnings
warnings.filterwarnings("ignore")

# ===================== 配置 =====================
DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
NUM_CLASSES = 91
MODEL_PATH = "./faster_rcnn_coco_result/faster_rcnn_coco.pth"
TEST_IMG_DIR = "./coco/val2017"
TEST_ANN = "./coco/annotations/instances_val2017.json"
SAVE_DIR = Path("./faster_rcnn_result_coco")
SAVE_DIR.mkdir(exist_ok=True)

# ===================== COCO 数据集 =====================
class COCOFull(CocoDetection):
    def __init__(self, img_root, ann_file):
        super().__init__(img_root, ann_file, transform=ToTensor())

    def __getitem__(self, idx):
        img, target = super().__getitem__(idx)
        boxes = []
        labels = []
        for obj in target:
            x, y, w, h = obj["bbox"]
            boxes.append([x, y, x + w, y + h])
            labels.append(obj["category_id"])
        return img, {
            "boxes": torch.tensor(boxes, dtype=torch.float32),
            "labels": torch.tensor(labels, dtype=torch.int64)
        }

# ===================== 模型 =====================
def load_model():
    model = fasterrcnn_resnet50_fpn_v2(weights=None)
    in_feat = model.roi_heads.box_predictor.cls_score.in_features
    model.roi_heads.box_predictor = FastRCNNPredictor(in_feat, NUM_CLASSES)
    model.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE))
    model.to(DEVICE).eval()
    return model

# ===================== 全量评估 =====================
def evaluate_full(model, val_loader):
    metric = MeanAveragePrecision(iou_type="bbox").to(DEVICE)
    with torch.no_grad():
        for imgs, targets in tqdm(val_loader, desc="Evaluating COCO Full"):
            imgs = [img.to(DEVICE) for img in imgs]
            targets = [{k: v.to(DEVICE) for k, v in t.items()} for t in targets]
            preds = model(imgs)
            metric.update(preds, targets)

    res = metric.compute()
    return {
        "mAP50": round(float(res["map_50"]), 3),
        "mAP": round(float(res["map"]), 3),
        "precision": round(float(res["precision"].mean()), 3),
        "recall": round(float(res["recall"].mean()), 3)
    }

# ===================== 主程序 =====================
if __name__ == "__main__":
    val_ds = COCOFull(TEST_IMG_DIR, TEST_ANN)
    val_loader = DataLoader(val_ds, batch_size=1, shuffle=False, collate_fn=lambda x: tuple(zip(*x)))

    print("加载模型...")
    model = load_model()
    print("开始全量评估...")

    metrics = evaluate_full(model, val_loader)
    params = sum(p.numel() for p in model.parameters()) / 1e6

    df = pd.DataFrame([{
        "model": "FasterRCNN_ResNet50",
        "dataset": "COCO2017",
        "mAP50": metrics["mAP50"],
        "mAP": metrics["mAP"],
        "precision": metrics["precision"],
        "recall": metrics["recall"],
        "params(M)": round(params, 2)
    }])

    df.to_csv(SAVE_DIR / "coco_final_results.csv", index=False)
    print("\n评估完成！")
    print(df)